<?php
session_start();
if(!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    die();
}
require_once "db.php";

$uid = $_SESSION['user_id'];
$act = $_POST['action'];

if($act == 'add') {
    $gname = mysqli_real_escape_string($conn, $_POST['group_name']);
    $ins = "INSERT INTO groups (user_id, group_name) VALUES ($uid, '$gname')";
    mysqli_query($conn, $ins);
    header("Location: groups.php");
} 
else if($act == 'edit') {
    $gid = (int)$_POST['group_id'];
    $gname = mysqli_real_escape_string($conn, $_POST['group_name']);
    $upd = "UPDATE groups SET group_name = '$gname' WHERE group_id = $gid AND user_id = $uid";
    mysqli_query($conn, $upd);
    header("Location: groups.php");
} 
else {
    header("Location: groups.php");
}
die();
?>

