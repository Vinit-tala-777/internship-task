<?php
session_start();
if(!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    die();
}
require_once "db.php";

$uid = $_SESSION['user_id'];
$act = $_POST['action'];
$gid = (int)$_POST['group_id'];

// make sure group belongs to user
$vq = "SELECT * FROM groups WHERE group_id = $gid AND user_id = $uid";
$vr = mysqli_query($conn, $vq);
if(mysqli_num_rows($vr) == 0) {
    header("Location: groups.php");
    die();
}

if($act == 'add') {
    $fname = mysqli_real_escape_string($conn, $_POST['first_name']);
    $lname = mysqli_real_escape_string($conn, $_POST['last_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    
    $ins = "INSERT INTO contacts (group_id, first_name, last_name, email, phone) VALUES ($gid, '$fname', '$lname', '$email', '$phone')";
    mysqli_query($conn, $ins);
    header("Location: contacts.php?group_id=$gid");
} 
else if($act == 'edit') {
    $cid = (int)$_POST['contact_id'];
    $fname = mysqli_real_escape_string($conn, $_POST['first_name']);
    $lname = mysqli_real_escape_string($conn, $_POST['last_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    
    $upd = "UPDATE contacts SET first_name = '$fname', last_name = '$lname', email = '$email', phone = '$phone' WHERE contact_id = $cid AND group_id = $gid";
    mysqli_query($conn, $upd);
    header("Location: contacts.php?group_id=$gid");
} 
else {
    header("Location: contacts.php?group_id=$gid");
}
die();
?>

