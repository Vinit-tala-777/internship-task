<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="container">
    <div class="form_area">
        <p class="title">LOGIN</p>

        <form action="login-process.php" method="post">
            <div class="form_group">
                <label class="sub_title">Name</label>
                <input type="text" name="username" class="form_style" placeholder="Enter username" required>
            </div>

            <div class="form_group">
                <label class="sub_title">Password</label>
                <input type="password" name="password" class="form_style" placeholder="Enter password" required>
            </div>

            <button type="submit" class="btn">LOGIN</button>
        </form>
    </div>
</div>

</body>
</html>
