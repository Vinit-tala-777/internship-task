<?php
session_start();
if(!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    die();
}
require_once "db.php";

$user_id = $_SESSION['user_id'];

// delete group if requested
if(isset($_GET['delete']) && isset($_GET['group_id'])) {
    $gid = (int)$_GET['group_id'];
    $del = "DELETE FROM groups WHERE group_id = $gid AND user_id = $user_id";
    mysqli_query($conn, $del);
    header("Location: groups.php");
    die();
}

// get all groups
$qry = "SELECT * FROM groups WHERE user_id = $user_id ORDER BY created_at DESC";
$res = mysqli_query($conn, $qry);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Groups</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="dashboard_area">
            <h2 class="title">Groups</h2>
            
            <div class="nav_links">
                <a href="dashborad.php" class="link">← Back to Dashboard</a>
            </div>

            <!-- form for add/edit -->
            <div class="form_area">
                <p class="sub_title"><?php if(isset($_GET['edit'])) echo 'Edit Group'; else echo 'Add New Group'; ?></p>
                <form method="post" action="group-actions.php">
                    <?php 
                    if(isset($_GET['edit']) && isset($_GET['group_id'])) {
                        $egid = (int)$_GET['group_id'];
                        $eq = "SELECT * FROM groups WHERE group_id = $egid AND user_id = $user_id";
                        $er = mysqli_query($conn, $eq);
                        $eg = mysqli_fetch_assoc($er);
                    ?>
                        <input type="hidden" name="action" value="edit">
                        <input type="hidden" name="group_id" value="<?php echo $egid; ?>">
                        <div class="form_group">
                            <label class="sub_title">Group Name</label>
                            <input type="text" name="group_name" class="form_style" value="<?php echo $eg['group_name']; ?>" required>
                        </div>
                        <button type="submit" class="btn">Update Group</button>
                        <a href="groups.php" class="btn cancel_btn">Cancel</a>
                    <?php } else { ?>
                        <input type="hidden" name="action" value="add">
                        <div class="form_group">
                            <label class="sub_title">Group Name</label>
                            <input type="text" name="group_name" class="form_style" placeholder="Enter group name" required>
                        </div>
                        <button type="submit" class="btn">Add Group</button>
                    <?php } ?>
                </form>
            </div>

            <!-- list all groups -->
            <div class="table_area">
                <h3 class="sub_title">Your Groups</h3>
                <?php 
                if(mysqli_num_rows($res) > 0) {
                ?>
                    <table class="data_table">
                        <thead>
                            <tr>
                                <th>Group Name</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            while($g = mysqli_fetch_assoc($res)) {
                            ?>
                                <tr>
                                    <td><?php echo $g['group_name']; ?></td>
                                    <td><?php echo date('Y-m-d H:i', strtotime($g['created_at'])); ?></td>
                                    <td class="action_buttons">
                                        <a href="contacts.php?group_id=<?php echo $g['group_id']; ?>" class="btn_small view_btn">View Contacts</a>
                                        <a href="groups.php?edit=1&group_id=<?php echo $g['group_id']; ?>" class="btn_small edit_btn">Edit</a>
                                        <a href="groups.php?delete=1&group_id=<?php echo $g['group_id']; ?>" class="btn_small delete_btn" onclick="return confirm('Delete this group? All contacts will be deleted too.');">Delete</a>
                                    </td>
                                </tr>
                            <?php 
                            }
                            ?>
                        </tbody>
                    </table>
                <?php 
                } else {
                    echo '<p class="no_data">No groups found. Create your first group above!</p>';
                }
                ?>
            </div>
        </div>
    </div>
</body>
</html>

