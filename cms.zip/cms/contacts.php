<?php
session_start();
if(!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    die();
}
require_once "db.php";

$uid = $_SESSION['user_id'];
$gid = isset($_GET['group_id']) ? (int)$_GET['group_id'] : 0;

// check if group belongs to user
if($gid > 0) {
    $chk = "SELECT * FROM groups WHERE group_id = $gid AND user_id = $uid";
    $chk_res = mysqli_query($conn, $chk);
    if(mysqli_num_rows($chk_res) == 0) {
        header("Location: groups.php");
        die();
    }
    $grp = mysqli_fetch_assoc($chk_res);
} else {
    header("Location: groups.php");
    die();
}

// delete contact
if(isset($_GET['delete']) && isset($_GET['contact_id'])) {
    $cid = (int)$_GET['contact_id'];
    $del = "DELETE FROM contacts WHERE contact_id = $cid AND group_id = $gid";
    mysqli_query($conn, $del);
    header("Location: contacts.php?group_id=$gid");
    die();
}

// get contacts
$cnt_qry = "SELECT * FROM contacts WHERE group_id = $gid ORDER BY created_at DESC";
$cnt_res = mysqli_query($conn, $cnt_qry);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contacts - <?php echo htmlspecialchars($group['group_name']); ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="dashboard_area">
            <h2 class="title">Contacts - <?php echo $grp['group_name']; ?></h2>
            
            <div class="nav_links">
                <a href="groups.php" class="link">← Back to Groups</a>
            </div>

            <!-- contact form -->
            <div class="form_area">
                <p class="sub_title"><?php if(isset($_GET['edit'])) echo 'Edit Contact'; else echo 'Add New Contact'; ?></p>
                <form method="post" action="contact-actions.php">
                    <input type="hidden" name="group_id" value="<?php echo $gid; ?>">
                    <?php 
                    if(isset($_GET['edit']) && isset($_GET['contact_id'])) {
                        $ecid = (int)$_GET['contact_id'];
                        $ecq = "SELECT * FROM contacts WHERE contact_id = $ecid AND group_id = $gid";
                        $ecr = mysqli_query($conn, $ecq);
                        $ec = mysqli_fetch_assoc($ecr);
                    ?>
                        <input type="hidden" name="action" value="edit">
                        <input type="hidden" name="contact_id" value="<?php echo $ecid; ?>">
                        <div class="form_group">
                            <label class="sub_title">First Name</label>
                            <input type="text" name="first_name" class="form_style" value="<?php echo $ec['first_name']; ?>" required>
                        </div>
                        <div class="form_group">
                            <label class="sub_title">Last Name</label>
                            <input type="text" name="last_name" class="form_style" value="<?php echo $ec['last_name']; ?>" required>
                        </div>
                        <div class="form_group">
                            <label class="sub_title">Email</label>
                            <input type="email" name="email" class="form_style" value="<?php echo $ec['email']; ?>" required>
                        </div>
                        <div class="form_group">
                            <label class="sub_title">Phone</label>
                            <input type="text" name="phone" class="form_style" value="<?php echo $ec['phone']; ?>" required>
                        </div>
                        <button type="submit" class="btn">Update Contact</button>
                        <a href="contacts.php?group_id=<?php echo $gid; ?>" class="btn cancel_btn">Cancel</a>
                    <?php } else { ?>
                        <input type="hidden" name="action" value="add">
                        <div class="form_group">
                            <label class="sub_title">First Name</label>
                            <input type="text" name="first_name" class="form_style" placeholder="Enter first name" required>
                        </div>
                        <div class="form_group">
                            <label class="sub_title">Last Name</label>
                            <input type="text" name="last_name" class="form_style" placeholder="Enter last name" required>
                        </div>
                        <div class="form_group">
                            <label class="sub_title">Email</label>
                            <input type="email" name="email" class="form_style" placeholder="Enter email" required>
                        </div>
                        <div class="form_group">
                            <label class="sub_title">Phone</label>
                            <input type="text" name="phone" class="form_style" placeholder="Enter phone number" required>
                        </div>
                        <button type="submit" class="btn">Add Contact</button>
                    <?php } ?>
                </form>
            </div>

            <!-- contacts list -->
            <div class="table_area">
                <h3 class="sub_title">Contacts List</h3>
                <?php 
                if(mysqli_num_rows($cnt_res) > 0) {
                ?>
                    <table class="data_table">
                        <thead>
                            <tr>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            while($c = mysqli_fetch_assoc($cnt_res)) {
                            ?>
                                <tr>
                                    <td><?php echo $c['first_name']; ?></td>
                                    <td><?php echo $c['last_name']; ?></td>
                                    <td><?php echo $c['email']; ?></td>
                                    <td><?php echo $c['phone']; ?></td>
                                    <td class="action_buttons">
                                        <a href="contacts.php?group_id=<?php echo $gid; ?>&edit=1&contact_id=<?php echo $c['contact_id']; ?>" class="btn_small edit_btn">Edit</a>
                                        <a href="contacts.php?group_id=<?php echo $gid; ?>&delete=1&contact_id=<?php echo $c['contact_id']; ?>" class="btn_small delete_btn" onclick="return confirm('Delete this contact?');">Delete</a>
                                    </td>
                                </tr>
                            <?php 
                            }
                            ?>
                        </tbody>
                    </table>
                <?php 
                } else {
                    echo '<p class="no_data">No contacts found. Add your first contact above!</p>';
                }
                ?>
            </div>
        </div>
    </div>
</body>
</html>

