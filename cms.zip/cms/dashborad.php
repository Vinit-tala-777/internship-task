<?php
session_start();
if(!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    die();
}
require_once "db.php";
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <div class="dashboard_area">
            <h2 class="title">Welcome, <?php echo $_SESSION['username']; ?>!</h2>
            
            <div class="dashboard_nav">
                <a href="groups.php" class="btn">Groups</a>
                <a href="logout.php" class="btn logout_btn">Logout</a>
            </div>
        </div>
    </div>
</body>
</html>
