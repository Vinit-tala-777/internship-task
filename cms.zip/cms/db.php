<?php
$conn = mysqli_connect("localhost", "root", "", "cms");

if (!$conn) {
    die("Database connection failed");
}
?>
